﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SprashControl : MonoBehaviour
{
    private Rigidbody2D rb;

    void Start()
    {
        Destroy(gameObject, 5);
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        rb.velocity = new Vector2(5, rb.velocity.y);
    }
}