﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    GameObject button;
    GameObject cast;
    GameObject player;
    int count = 0;
    public bool exist = true;
    // Start is called before the first frame update

    void Start()
    {
        button = GameObject.FindGameObjectWithTag("start");
        player = GameObject.FindGameObjectWithTag("Player");
        cast = GameObject.FindGameObjectWithTag("cast");
    }

    // Update is called once per frame
    void Update()
    {
        cast.transform.position = new Vector2(player.transform.position.x, player.transform.position.y);
        if (count == 5 && exist)
        {
            button.SetActive(false);
            exist = false;
        }
        else if (Math.Abs(cast.transform.position.x - button.transform.position.x) < 0.00625 && Math.Abs(cast.transform.position.y - button.transform.position.y) < 0.5)
            count++;
        Debug.Log(count);
    }
}
