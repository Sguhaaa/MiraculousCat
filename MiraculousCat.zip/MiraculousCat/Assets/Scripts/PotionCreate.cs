﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PotionCreate : MonoBehaviour
{
    public FadeInOut fading;

    public bool[] array;
    int count = 0;
    // Start is called before the first frame update
    void Start()
    {
        array = new bool[12];
    }
    void Update()
    {
        if (count == 3)
        {
            if (array[0] && !array[2])
                fading.nextLevel = "Assets/Scenes/Prihod.unity";
            else
                fading.nextLevel = "Assets/Scenes/Menu.unity";
            fading.sceneEnd = true;
        }
    }
    // Update is called once per frame
    public void TapWaterButton()
    {
        array[0] = true;
        count++;
    }

    public void TapFeatherButton()
    {
        array[1] = true;
        count++;
    }
    public void TapBarkButton()
    {
        array[2] = true;
        count++;
    }
    public void TapCoalButton()
    {
        array[3] = true;
        count++;
    }

   
}
