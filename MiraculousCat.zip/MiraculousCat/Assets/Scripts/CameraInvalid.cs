﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraInvalid : MonoBehaviour
{
    Camera cam; 
    // Start is called before the first frame update
    void Start()
    {
        cam = GetComponent<Camera>();
        cam.transform.position = new Vector3(-0.97f, 2.262241f, -8f);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
            cam.transform.position = new Vector3(cam.transform.position.x + 0.05f, 2.262241f, -8f);
    }
}
