﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnMouse : MonoBehaviour
{
    // Start is called before the first frame update
    Color def;

    void Start()
    {
        def = GetComponent<Renderer>().material.color;
    }

    void OnMouseEnter()
    {
        GetComponent<Renderer>().material.color = Color.gray;
    }

    void OnMouseExit()
    {
        GetComponent<Renderer>().material.color = def;
    }
}
