﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ext : MonoBehaviour
{
    public FadeInOut fading;
    // Start is called before the first frame update
    void Start()
    {
       // fading.sceneEnd = true;
    }

    // Update is called once per frame
    void Update()
    {
    }
}
