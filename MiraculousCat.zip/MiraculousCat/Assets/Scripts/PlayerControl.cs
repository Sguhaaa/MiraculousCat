﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public float speed;
    public Rigidbody2D splash;
    public Rigidbody2D sprash;
    public bool isShoot;

    private Rigidbody2D player;
    private Animator anim;
    private bool isRightSide;
    
    void Start()
    {
        player = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        isRightSide = false;
    }
    
    void FixedUpdate()
    {
        float moveX = Input.GetAxis("Horizontal");
        player.velocity = new Vector2(moveX * speed, player.velocity.y);
        anim.SetFloat("Speed", Math.Abs(player.velocity.x));

        if ((moveX > 0f && !isRightSide) || (moveX < 0f && isRightSide))
        {
            if (moveX != 0f) Spin();
        }

        if (Input.GetKeyDown(KeyCode.F))
        {
            anim.SetBool("IsShoot", true);
            isShoot = true;
            if(isRightSide) FireRight();
            else FireLeft();
            return;
        }

        if (Input.GetKeyUp(KeyCode.F))
        {
            anim.SetBool("IsShoot", false);
            isShoot = false;
        }
    }
    
    void Spin()
    {
        isRightSide = !isRightSide;
        transform.localScale = new Vector3(transform.localScale.x * -1, 1f, 1f);
    }
    
    void FireLeft()
    {
        Rigidbody2D bullet = Instantiate(splash, new Vector3(player.position.x - 0.3f, player.position.y - 0.2f), Quaternion.identity) as Rigidbody2D;
    }

    void FireRight()
    {
        Rigidbody2D bullet = Instantiate(sprash, new Vector3(player.position.x + 0.3f, player.position.y - 0.2f), Quaternion.identity) as Rigidbody2D;
    }
}
