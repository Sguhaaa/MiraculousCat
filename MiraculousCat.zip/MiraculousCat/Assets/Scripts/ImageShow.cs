﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImageShow : MonoBehaviour
{
    private Image image;

    void Awake()
    {
        image = GetComponent<Image>();
        image.enabled = false;
    }

    public void Show()
    {
        image.enabled = true;
    }

    public void Close()
    {
       image.enabled = false;
    }
}
