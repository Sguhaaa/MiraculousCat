﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemsClicks : MonoBehaviour
{
    GameObject tree;
    GameObject player;
    GameObject snow;
    GameObject fire;
    GameObject koster;
    GameObject cloud;

    public FadeInOut fading;

    bool tr = false;
    public void Start()
    {
        tree = GameObject.FindGameObjectWithTag("tree");
        fire = GameObject.FindGameObjectWithTag("fire");
        player = GameObject.FindGameObjectWithTag("Player");
        snow = GameObject.FindGameObjectWithTag("snow");
        koster = GameObject.FindGameObjectWithTag("koster");
        cloud = GameObject.FindGameObjectWithTag("cloud");
    }
    public void Update()
    {
        if (tr)
        {
            tree.transform.position = new Vector3(player.transform.position.x - 0.6f, player.transform.position.y + 1.2f, -2);
            StartCoroutine(SetPause());
        }
        else
            tree.transform.position = new Vector3(-100, -100, -1);

    }

    IEnumerator SetPause()
    {
        yield return new WaitForSeconds(2);
        tr = false;
        fire.transform.position = new Vector3(player.transform.position.x - 0.6f, player.transform.position.y + 1.2f, -2);
        StartCoroutine(SetPause(fire,2));
    }

    IEnumerator SetPause(GameObject go, int time)
    {
        yield return new WaitForSeconds(time);
        go.transform.position = new Vector3(-100, -100, -1);
    }

    public void TapTree()
    {
        tr = true;
    }

    public void TapSnowButton()
    {
        koster.transform.position = new Vector3(28.3f,0.65f, -2);
        snow.SetActive(false);
        cloud.transform.position = new Vector3(31.02f,3.07f, -2);
        StartCoroutine(SetPause(cloud,7));
    }

    public void TapFireButton()
    {
        fading.nextLevel = "Assets/Scenes/Brewing.unity";
        fading.sceneEnd = true;
    }
}
