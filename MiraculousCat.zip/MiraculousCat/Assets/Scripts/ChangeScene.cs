﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{
    public FadeInOut fading;

    void Awake()
    {
        GetComponent<Animator>().speed = 0;
    }

    void OnMouseDown()
    {
        GetComponent<Animator>().speed = 1;
        fading.sceneEnd = true;
    }
}
