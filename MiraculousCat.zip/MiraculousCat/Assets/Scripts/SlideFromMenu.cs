﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlideFromMenu : MonoBehaviour
{
    public FadeInOut fading;

    public void TapWhiteButton()
    {
        fading.nextLevel = "Assets/Scenes/First.unity";
        fading.sceneEnd = true;
    }

    public void TapOrangeButton()
    {
        fading.nextLevel = "Assets/Scenes/Second.unity";
        fading.sceneEnd = true;
    }

    public void TapPurpleButton()
    {
        fading.nextLevel = "Assets/Scenes/Third.unity";
        fading.sceneEnd = true;
    }
}
