﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using System.Net;
using System.Text.RegularExpressions;
using System;

public class TheWeather : MonoBehaviour
{
    string weather;
    bool snow = false;
    private ParticleSystem particleSystem;
    // Start is called before the first frame update
    void Start()
    {
        particleSystem = GetComponent<ParticleSystem>();
        particleSystem.Stop();
        WebClient wc = new WebClient();
        wc.Encoding = Encoding.UTF8;
        string response = wc.DownloadString("https://yandex.ru/pogoda/chelyabinsk");
        weather = Regex.Match(response, @"class=""link__condition day-anchor i-bem"" data-bem='{""day-anchor"":{""anchor"":[0-9]+}}'>([А-яЁё ]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase).Groups[1].Value;
        weather = weather.ToLower();
    }

    // Update is called once per frame
    void Update()
    {
        if ((weather.Contains("облачно") || weather.Contains("снег") || weather.Contains("пасмурно")) && !snow)
        {
            particleSystem.Play();
            snow = true;
        }
        if (weather.Contains("ясно") || weather.Contains("переменная") && snow)
        {
            particleSystem.Stop();
            snow = false;
        }

    }
}
