﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class PlayerMovement : MonoBehaviour
{
    public Vector2 speed = new Vector2(50, 50);
    // 2 - направление движения
    private Vector2 movement;
    private GameObject player;
    private GameObject cloud;
    private GameObject button;
    private bool isCol;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        cloud = GameObject.FindGameObjectWithTag("cloud");
        button = GameObject.FindGameObjectWithTag("start");
    }

    void Update()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");


        if (Math.Abs(player.transform.position.x - button.transform.position.x) < 0.5 && Math.Abs(player.transform.position.y - button.transform.position.y) < 0.5)
        {
            cloud.transform.position = new Vector2(player.transform.position.x - 0.3f, player.transform.position.y + 0.3f);
            isCol = true;
        }
        else
        {
            cloud.transform.position = new Vector2(-100, -100);
            isCol = false;
        }
        if (isCol)
        {
            if (Input.GetKeyDown(KeyCode.F))
                Debug.Log("sos");

        }

        movement = new Vector2(
          speed.x * inputX, inputY);

    }

    void FixedUpdate()
    {

        GetComponent<Rigidbody2D>().velocity = movement;
    }
}
